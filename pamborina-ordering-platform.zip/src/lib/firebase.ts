import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import {
  initializeFirestore,
  getFirestore,
  Firestore,
  memoryLocalCache,
  persistentLocalCache,
  persistentMultipleTabManager,
  setLogLevel,
} from 'firebase/firestore';
import { getAuth, Auth } from 'firebase/auth';
import { getStorage, FirebaseStorage } from 'firebase/storage';

// Suppress non-fatal Firestore internal logs (such as BloomFilterError and offline/reconnection notices)
try {
  setLogLevel('silent');
} catch {}

if (typeof window !== 'undefined') {
  const originalWarn = console.warn.bind(console);
  console.warn = (...args: any[]) => {
    try {
      const fullText = args
        .map((arg) => {
          if (typeof arg === 'string') return arg;
          if (arg instanceof Error) return `${arg.name} ${arg.message}`;
          try {
            return JSON.stringify(arg);
          } catch {
            return String(arg);
          }
        })
        .join(' ');

      if (
        fullText.includes('BloomFilter') ||
        fullText.includes('BloomFilterError') ||
        fullText.includes('Applying bloom filter failed') ||
        fullText.includes('Could not reach Cloud Firestore backend') ||
        fullText.includes('operate in offline mode') ||
        fullText.includes('using local products') ||
        fullText.includes('fetch request timed out') ||
        fullText.includes('timed out')
      ) {
        return; // Suppress harmless internal Firestore warnings
      }
    } catch {}
    originalWarn.apply(console, args);
  };

  const originalError = console.error.bind(console);
  console.error = (...args: any[]) => {
    try {
      const fullText = args
        .map((arg) => {
          if (typeof arg === 'string') return arg;
          if (arg instanceof Error) return `${arg.name} ${arg.message}`;
          try {
            return JSON.stringify(arg);
          } catch {
            return String(arg);
          }
        })
        .join(' ');

      if (
        fullText.includes('Could not reach Cloud Firestore backend') ||
        fullText.includes('operate in offline mode') ||
        (fullText.includes('@firebase/firestore') && fullText.includes('unavailable'))
      ) {
        return; // Suppress harmless internal Firestore offline/reconnection messages
      }
    } catch {}
    originalError.apply(console, args);
  };
}

// Helper to safely read env variables in both Vite client and Node scripts
const getEnvVar = (key: string): string => {
  if (typeof import.meta !== 'undefined' && import.meta.env && import.meta.env[key]) {
    return import.meta.env[key];
  }
  if (typeof process !== 'undefined' && process.env && process.env[key]) {
    return process.env[key] as string;
  }
  return '';
};

// Firebase configuration from environment variables with fallback configuration
const firebaseConfig = {
  apiKey: getEnvVar('VITE_FIREBASE_API_KEY') || 'AIzaSyA3KZCOwVykq5EUeJsK8RMEE0LMaYZx_nM',
  authDomain: getEnvVar('VITE_FIREBASE_AUTH_DOMAIN') || 'pamborina-app.firebaseapp.com',
  projectId: getEnvVar('VITE_FIREBASE_PROJECT_ID') || 'pamborina-app',
  storageBucket: getEnvVar('VITE_FIREBASE_STORAGE_BUCKET') || 'pamborina-app.firebasestorage.app',
  messagingSenderId: getEnvVar('VITE_FIREBASE_MESSAGING_SENDER_ID') || '1004537773887',
  appId: getEnvVar('VITE_FIREBASE_APP_ID') || '1:1004537773887:web:e036a8b9761a4207f35d8a',
  measurementId: getEnvVar('VITE_FIREBASE_MEASUREMENT_ID') || 'G-JMYMRX50FV',
};

/**
 * Validates whether essential Firebase credentials are provided.
 */
export const isFirebaseConfigured = (): boolean => {
  return Boolean(
    firebaseConfig.apiKey &&
    firebaseConfig.projectId &&
    firebaseConfig.apiKey !== 'MY_FIREBASE_API_KEY' &&
    firebaseConfig.projectId !== 'MY_FIREBASE_PROJECT_ID'
  );
};

let app: FirebaseApp | null = null;
let db: Firestore | null = null;
let auth: Auth | null = null;
let storage: FirebaseStorage | null = null;

let isInitialized = false;
let initializationError: string | null = null;

if (isFirebaseConfigured()) {
  try {
    app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
    
    // Safely initialize Firestore with multi-tab support, long-polling fallback, and memory cache fallback
    try {
      db = initializeFirestore(app, {
        localCache: persistentLocalCache({
          tabManager: persistentMultipleTabManager(),
        }),
        experimentalAutoDetectLongPolling: true,
      });
    } catch {
      try {
        db = getFirestore(app);
      } catch {
        db = initializeFirestore(app, {
          localCache: memoryLocalCache(),
          experimentalAutoDetectLongPolling: true,
        });
      }
    }

    auth = getAuth(app);
    storage = getStorage(app);
    isInitialized = true;
    console.log('[Firestore] Connected with resilient cache');
  } catch (error: any) {
    initializationError = error?.message || 'Unknown initialization error';
    console.warn('⚠️ [Firebase] Initialization error:', initializationError);
  }
} else {
  console.info('ℹ️ [Firebase] Environment variables not set or incomplete. Running in Static Local Data mode.');
}

/**
 * Connectivity test function to verify Firebase initialization status safely.
 */
export const testFirebaseConnection = (): {
  configured: boolean;
  initialized: boolean;
  app: FirebaseApp | null;
  db: Firestore | null;
  auth: Auth | null;
  storage: FirebaseStorage | null;
  error: string | null;
} => {
  return {
    configured: isFirebaseConfigured(),
    initialized: isInitialized,
    app,
    db,
    auth,
    storage,
    error: initializationError,
  };
};

export { app, db, auth, storage };
export default app;
